# Pulse backend API contract (MVP)

All endpoints use HTTPS. Private provider credentials and storage secrets stay on the server, never in the Android APK.

## Public/authenticated endpoints

- `GET /v1/catalog/featured` — approved artists, albums and tracks available in the request territory.
- `GET /v1/catalog/search?q={query}&type={all|track|artist|album}` — search published catalog metadata only.
- `GET /v1/tracks/{trackId}` — track metadata and availability; no permanent audio URL.
- `POST /v1/tracks/{trackId}/playback` — authenticate user/guest, check territory and rights dates, then return a short-lived provider token or signed stream URL plus expiry.
- `GET /v1/me/playlists` — list current user's playlists.
- `POST /v1/me/playlists` — create playlist.
- `PUT /v1/me/playlists/{playlistId}/tracks` — replace/reorder playlist track IDs after ownership and catalog checks.
- `PUT /v1/me/likes/{trackId}` — like a track.
- `DELETE /v1/me/likes/{trackId}` — unlike a track.
- `POST /v1/play-events` — record a qualified listening event for royalty reporting; validate server-side and avoid trusting client claims blindly.

## Playback response example

```json
{
  "trackId": "uuid",
  "streamUrl": "short-lived-https-url-or-provider-approved-url",
  "expiresAt": "2026-10-11T12:00:00Z",
  "mimeType": "audio/mpeg"
}
```

This is a contract example, not a live endpoint. Implement against the selected licensed catalog and storage provider's actual API.

## Security requirements

- Use Supabase Auth or an equivalent identity provider; apply database row-level security to every user-owned table.
- Keep service-role keys and provider secrets only in server-side environment variables.
- Store audio in private object storage; use short-lived signed URLs or provider playback tokens.
- Validate track rights, start/end dates and territory on every playback authorization.
- Rate-limit playback-token requests; log security events without logging secrets.
- Provide account deletion, privacy policy, terms, and data retention rules.
