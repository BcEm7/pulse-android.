# Build and download the Pulse Android APK

This repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`. It builds a **debug APK** in GitHub's cloud and stores it as an artifact for 14 days. This environment does not have the Android SDK or Gradle installed, so it cannot compile and verify an APK locally.

## Create the APK using GitHub (computer or mobile browser)

1. Sign in to GitHub and create a new **private** repository, for example `pulse-android`.
2. Extract the `pulse_android` folder from the ZIP on your computer. Upload the *contents* of that folder to the repository (including the hidden `.github` folder). If uploading from a phone is difficult, use a computer or GitHub's web upload interface.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and choose **Build Pulse Android APK**. If the workflow has not started automatically, select **Run workflow**.
5. Wait for the workflow to finish. Open the completed run and download the `Pulse-debug-APK` artifact.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and open it. If Android asks, allow installation from that source. Only install APKs from a repository you control and trust.

## Important limitations

- This is a debug/test APK, not a production release. It is signed with a debug key.
- The current app is a UI starter. The player controls do not yet connect to a live catalog or licensed streaming backend, so this APK is not a complete Spotify-like streaming service.
- No commercial music is bundled. Streaming music requires permission for the relevant recordings and compositions.
- Keep the GitHub repository private while the app is in development.
