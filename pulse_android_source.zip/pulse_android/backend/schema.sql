-- Pulse MVP database schema (PostgreSQL / Supabase)
-- Do not store public audio files in a bucket accessible to anonymous users.
-- Signed URLs or provider-authorized playback tokens should be issued server-side.

create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table public.artists (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  bio text,
  country_code char(2),
  approved_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.albums (
  id uuid primary key default gen_random_uuid(),
  artist_id uuid not null references public.artists(id),
  title text not null,
  cover_art_path text,
  release_date date,
  created_at timestamptz not null default now()
);

create table public.tracks (
  id uuid primary key default gen_random_uuid(),
  album_id uuid references public.albums(id),
  artist_id uuid not null references public.artists(id),
  title text not null,
  duration_seconds integer check (duration_seconds > 0),
  audio_object_key text not null,
  is_published boolean not null default false,
  territory_codes text[] not null default array['ET']::text[],
  rights_start timestamptz,
  rights_end timestamptz,
  explicit_content boolean not null default false,
  created_at timestamptz not null default now()
);
create index tracks_search_idx on public.tracks using gin (to_tsvector('simple', title));
create index tracks_artist_idx on public.tracks (artist_id);

create table public.rights_documents (
  id uuid primary key default gen_random_uuid(),
  track_id uuid not null references public.tracks(id) on delete cascade,
  rights_holder_name text not null,
  agreement_reference text not null,
  permitted_uses text[] not null,
  territory_codes text[] not null,
  effective_from date not null,
  effective_until date,
  royalty_terms_note text,
  verified_by uuid references auth.users(id),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.playlists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  is_public boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.playlist_tracks (
  playlist_id uuid not null references public.playlists(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  position integer not null check (position >= 0),
  added_at timestamptz not null default now(),
  primary key (playlist_id, track_id),
  unique (playlist_id, position)
);

create table public.user_likes (
  user_id uuid not null references auth.users(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

create table public.play_events (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete set null,
  track_id uuid not null references public.tracks(id),
  territory_code char(2) not null default 'ET',
  started_at timestamptz not null default now(),
  listened_seconds integer not null default 0 check (listened_seconds >= 0),
  client_version text
);
create index play_events_track_date_idx on public.play_events (track_id, started_at);

-- Enable RLS before exposing any tables through the client API.
alter table public.profiles enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_tracks enable row level security;
alter table public.user_likes enable row level security;
alter table public.play_events enable row level security;
alter table public.artists enable row level security;
alter table public.albums enable row level security;
alter table public.tracks enable row level security;
alter table public.rights_documents enable row level security;

-- Important: add reviewed policies before deployment. Keep rights_documents,
-- audio_object_key and private storage access unavailable to public clients.
-- The server should validate track publication, dates, territories, and user
-- authorization before returning a short-lived playback URL/token.
