package com.pulse.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Lime = Color(0xFFA7F36B)
private val Muted = Color(0xFFB7B7B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PulseApp() }
    }
}

private data class Track(val title: String, val artist: String, val artwork: String = "♪")
private val featured = listOf(
    Track("Discover Daily", "A mix made for your day", "✦"),
    Track("Fresh Frequencies", "New releases and emerging artists", "♫"),
    Track("Focus Flow", "Instrumental sounds for concentration", "◉"),
    Track("Ethiopian Sounds", "Explore music from Ethiopia", "♬")
)

@Composable
private fun PulseApp() {
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var liked by remember { mutableStateOf(setOf<String>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lime, onPrimary = Ink, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF080808), contentColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = navColors())
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") }, colors = navColors())
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Library") }, colors = navColors())
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Lime, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                        Text("≋", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("pulse", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    Text("AD-FREE", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                when (tab) {
                    0 -> HomeScreen(onSelect = { selected = it; isPlaying = false })
                    1 -> SearchScreen(query, { query = it }, featured.filter { (it.title + it.artist).contains(query, true) }, onSelect = { selected = it; isPlaying = false })
                    else -> LibraryScreen(liked.map { key -> featured.find { it.title == key } ?: Track(key, "Saved") }, onSelect = { selected = it; isPlaying = false })
                }
                selected?.let { track ->
                    PlayerBar(track, isPlaying, { isPlaying = !isPlaying }, { liked = if (track.title in liked) liked - track.title else liked + track.title })
                    Text("Playback is a UI preview. Connect a licensed catalog provider to stream full tracks.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(selectedIconColor = Lime, selectedTextColor = Lime, indicatorColor = Color(0xFF2B3822), unselectedIconColor = Muted, unselectedTextColor = Muted)

@Composable
private fun HomeScreen(onSelect: (Track) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Your sound, your way.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Premium-style listening. No ads. No subscription in this prototype.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().background(Lime, RoundedCornerShape(20.dp)).padding(20.dp)) {
                Column {
                    Text("LISTEN WITHOUT LIMITS", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Your next favorite is out there.", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Discover artists, albums, and playlists.", color = Ink, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(4.dp))
            Text("Made for your mood", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        items(featured) { track -> CollectionCard(track, onClick = { onSelect(track) }) }
        item {
            Text("Catalog connection needed", color = Lime, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("This starter app does not include commercial songs. A music-rights agreement and an authorized catalog API are required before streaming can be enabled.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun SearchScreen(query: String, onQuery: (String) -> Unit, tracks: List<Track>, onSelect: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Search", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Artists, songs, albums") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Lime, unfocusedBorderColor = Color.DarkGray, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Lime))
        Spacer(Modifier.height(14.dp))
        if (tracks.isEmpty()) Text("No matching demo collections. Search will include the licensed catalog once connected.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(tracks) { CollectionCard(it, onClick = { onSelect(it) }) } }
    }
}

@Composable
private fun LibraryScreen(saved: List<Track>, onSelect: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Your Library", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Playlists and liked songs will live here.", color = Muted)
        Spacer(Modifier.height(14.dp))
        if (saved.isEmpty()) Text("Your library is empty. Tap the heart in the player to save a collection.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(saved) { CollectionCard(it, onClick = { onSelect(it) }) } }
    }
}

@Composable
private fun CollectionCard(track: Track, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(58.dp).background(Color(0xFF30382A), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(track.artwork, color = Lime, fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(track.artist, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = "Preview collection", tint = Lime)
    }
}

@Composable
private fun PlayerBar(track: Track, playing: Boolean, onToggle: () -> Unit, onLike: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).background(Color(0xFF252B20), RoundedCornerShape(14.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = onLike) { Icon(Icons.Default.Favorite, contentDescription = "Like", tint = Lime) }
        IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "Pause" else "Play", tint = Color.White) }
    }
}
