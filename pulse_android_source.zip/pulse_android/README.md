# Pulse Android — starter project

Pulse is an original, ad-free music app starter for Android. It uses Kotlin, Jetpack Compose, and AndroidX Media3 dependencies. The UI includes Home, Search, Library, collection cards, a mini-player preview, and a save/like interaction.

## Important status

This is a source-code starter, **not a production-ready streaming service or installable APK**. The play/pause control currently previews UI state only; there are no commercial tracks or live streaming endpoint configured. The app intentionally does not include ad SDKs.

## Open the project

1. Install Android Studio (a recent stable version).
2. Open this `pulse_android` folder.
3. Allow Gradle sync and install the Android SDK required by `compileSdk = 35`.
4. Run the `app` configuration on an Android device or emulator.

A Gradle wrapper is not included in this initial source package; Android Studio can import the project, or a developer can generate a wrapper using a compatible Gradle installation.

## Before licensed music can stream

1. **Secure rights** for the intended territories and catalog. Depending on the business model and territory, rights may be needed for the sound recording (master) and the underlying musical composition, plus streaming, reproduction/cache, offline playback, and other uses. Rights holders and collection societies can clarify the relevant rights in each territory. Do not upload or stream commercial recordings without permission.
2. **Choose a provider that expressly permits a third-party consumer streaming app.** Many music APIs permit metadata, previews, or playback only inside the provider's own app and do not grant rights to build a competing full-catalog service. Obtain written commercial terms and confirm Ethiopia availability, territorial restrictions, royalty reporting, attribution, DRM, and offline-playback conditions.
3. **Build a backend** for catalog search, authentication, playlists, entitlements, signed stream URLs/tokens, abuse controls, usage/royalty reporting, and provider secrets. Do not embed private API secrets in the Android APK.
4. **Integrate authorized playback** through AndroidX Media3/ExoPlayer or the provider's approved SDK. Implement background playback, audio focus, headset controls, media notification, caching/offline access only if the license permits it, and secure token refresh.
5. **Productionize** with privacy policy, terms, data deletion, security testing, crash monitoring, accessibility, Google Play policy review, and release signing.

## Free-to-user model and cost limits

An ad-free service can be free to listeners, but it is not cost-free to operate. Licensing/royalties, catalog-provider minimums, bandwidth/CDN, storage, backend hosting, security, support, and app maintenance still need funding. Possible funding models include sponsorship that does not insert ads into playback, donations, grants, or a separate business subsidy; each must comply with rights-holder and provider contracts. Do not promise a complete Spotify-sized catalog or offline premium features until the provider contract specifically allows them and the budget supports them.

## Suggested next implementation milestones

- Define target launch territory (Ethiopia only or additional countries).
- Identify and contract with a rights-cleared catalog provider or directly license a smaller catalog from artists/labels.
- Add API configuration and a typed catalog repository.
- Implement Media3 playback service, queue, seek/progress, background controls, and authorized stream URLs.
- Add user accounts and cloud-synced playlists, then implement offline mode only if explicitly permitted.
- Run legal, security, and device testing before public release.
