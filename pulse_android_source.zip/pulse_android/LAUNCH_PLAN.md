# Pulse launch plan — ad-free Android streaming

## Scope for first release
- Android phone app; Ethiopia-first territory unless rights contracts say otherwise.
- 50–200 independent tracks with written streaming permission.
- Home/featured catalog, search, artist and track pages, play queue, background playback, likes, user playlists.
- Free for listeners, no ad SDKs, no paywall. Do not promise offline downloads in MVP.

## Rights checklist (complete before publishing any track)
1. Identify master recording owner and musical composition/songwriter/publisher rights holders. Confirm whether a label, distributor, publisher, collecting society or artist controls each right.
2. Get a signed agreement or a documented license from an authorized rights holder. Cover on-demand interactive streaming, territory (e.g. Ethiopia), term, monetization/free-to-user model, promotional clips, metadata/artwork, reporting, royalty calculation/payment, takedown, and termination.
3. Address reproduction/transient copies, caching, offline downloads, user-generated uploads and promotional uses separately; do not assume they are included.
4. Verify that the licensor has authority to grant the rights and that composition and master rights are both covered. Ask EIPA and relevant Ethiopian collective management organizations about applicable permissions, tariffs and reporting obligations.
5. Maintain per-track evidence: contract reference, rights holder, territories, dates, permitted uses, royalty terms and contact for takedowns. Disable tracks automatically when rights expire or a territory is not covered.
6. Ask Ethiopian counsel to review contracts and current local requirements before public launch. This checklist is operational guidance, not legal advice.

## Suggested architecture
- Android: Kotlin + Jetpack Compose + AndroidX Media3 ExoPlayer.
- Background playback: MediaSessionService + MediaSession; notification, lock-screen controls, audio focus, headset/Bluetooth controls and playback resumption.
- Backend: Supabase Auth/Postgres for accounts, catalog metadata, playlists, likes and play events; a server-side API/Edge Function for authorization and royalty events.
- Audio: private object storage/CDN or licensed provider stream. Never expose permanent public audio URLs or service-role keys in the APK. Use short-lived signed URLs/tokens and enforce territory/date checks on the server.
- Monitoring: crash reports, playback start failures, buffering, API errors, bandwidth alerts and royalty-report reconciliation.

## Cost model
Actual pricing depends on the chosen catalog contract, audience, territory, bandwidth and developer rates. Get written quotes before committing.

- Rights/royalties: negotiate directly with artists/labels and confirm collective-management obligations. Potentially the largest variable.
- Engineering: self-build can reduce cash costs but not time; paid Android/backend work is the largest upfront cost if outsourced.
- Hosting/database: free tiers can support development and small tests, but production plans and backups may be needed.
- Audio delivery: bandwidth/CDN usually grows with listening hours. At 128 kbps, rough audio payload is about 0.96 MB/minute; 100 listeners × 1 hour/day × 30 days is about 173 GB/month before protocol overhead and caching benefits. At 1,000 similar listeners it is about 1.73 TB/month.
- Other: domain, email, privacy/legal review, security testing, support, Play Console registration and device testing.

## Release gates
1. Rights and provider contract signed; approved starter catalog imported.
2. Backend staging deployed; RLS policies tested; private audio and signed playback authorization verified.
3. Media3 service integrated; background playback and interruptions tested.
4. Android Studio build succeeds; unit/UI tests and physical-device tests pass.
5. Privacy policy, terms, account deletion, support contact, content takedown workflow and Google Play declarations ready.
6. Generate a debug APK for private testing; sign a release APK/AAB for distribution. Keep signing keys secure and backed up.

## Testable APK steps
1. Install Android Studio and required Android SDK/build tools.
2. Open the `pulse_android` project and sync Gradle.
3. Add a development `BASE_URL` and backend configuration through build config/environment; do not put secret keys in the app.
4. Configure a staging backend and at least one cleared track, then implement the playback service and repository.
5. Run the app on an emulator and at least two physical Android devices. Test Wi-Fi/mobile data, app backgrounding, screen lock, calls/audio focus, headphones, seek, skip, network loss, expired token, and unavailable territory.
6. Use Android Studio **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a debug APK. The APK is only testable after the project compiles and backend configuration is supplied.
7. For external distribution, use a signed release build and follow current Google Play requirements. A Play Store account and any applicable registration fee are separate from development costs.

## Current starter status
The included UI source is a starter. Its current play control is a UI preview and it has no live catalog endpoint, backend, licensed audio stream, production authentication, or built APK. Those must be implemented and tested before it can be described as a streaming service.
